

class BannerVenda():
    pass