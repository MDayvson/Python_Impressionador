from kivy.uix.screenmanager import Screen


class HomePage(Screen):
    pass


class AjustesPage(Screen):
    pass